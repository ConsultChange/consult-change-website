<?php
/**
 * Plugin Name: VKGS Typography Pack
 * Description: Adds a clean "Letter" typography system (Inter Light/Regular) + Gutenberg block styles for headings and paragraphs.
 * Version: 1.0.0
 * Author: VKGS Consulting
 */
if ( ! defined('ABSPATH') ) exit;
define('VKGS_TYPO_URL', plugin_dir_url(__FILE__));
define('VKGS_TYPO_VER', '1.0.0');
add_action('enqueue_block_assets', function(){
  wp_enqueue_style('vkgs-typo-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500&display=swap', [], null);
  wp_enqueue_style('vkgs-typo-styles', VKGS_TYPO_URL . 'assets/typography.css', [], VKGS_TYPO_VER);
});
add_action('enqueue_block_editor_assets', function(){
  wp_enqueue_style('vkgs-typo-editor', VKGS_TYPO_URL . 'assets/editor.css', ['vkgs-typo-fonts','vkgs-typo-styles'], VKGS_TYPO_VER);
});
add_action('init', function(){
  if ( function_exists('register_block_style') ) {
    register_block_style('core/heading', [
      'name'  => 'vkgs-letter-heading',
      'label' => __('VKGS Letter — Heading', 'vkgs-typography'),
      'inline_style' => '.is-style-vkgs-letter-heading{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-weight:400;font-size:16px;line-height:1.6;letter-spacing:.005em;text-align:center;color:#0f172a;margin-bottom:12px;}'
    ]);
    register_block_style('core/paragraph', [
      'name'  => 'vkgs-letter-body',
      'label' => __('VKGS Letter — Body', 'vkgs-typography'),
      'inline_style' => '.is-style-vkgs-letter-body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-weight:300;font-size:13.5px;line-height:1.85;color:#334155;margin:0 0 14px;} .is-style-vkgs-letter-body strong{font-weight:500;color:#0f172a;}'
    ]);
  }
});