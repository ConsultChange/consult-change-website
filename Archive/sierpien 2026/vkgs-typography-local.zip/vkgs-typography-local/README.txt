Install: Plugins → Add New → Upload → vkgs-typography-local.zip → Activate.
Upload your font files into: /wp-content/plugins/vkgs-typography-local/assets/fonts/
Use names: ConsultChange-300/400/500.(woff2|woff|ttf|otf) or edit @font-face paths in assets/typography-local.css.
Use Styles panel: Heading → VKGS Letter — Heading; Paragraph → VKGS Letter — Body. Optional Group class: vkgs-letter-wrap.
