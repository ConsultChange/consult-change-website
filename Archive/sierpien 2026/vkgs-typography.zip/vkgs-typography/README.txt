Install: Plugins → Add New → Upload → vkgs-typography.zip → Activate.
Use Styles: select a Heading → Styles → VKGS Letter — Heading; Paragraph → Styles → VKGS Letter — Body.
Optional: wrap content in a Group and add CSS class vkgs-letter-wrap.
