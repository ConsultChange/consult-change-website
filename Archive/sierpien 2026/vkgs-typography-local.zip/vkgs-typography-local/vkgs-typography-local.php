<?php
/**
 * Plugin Name: VKGS Typography (Local Fonts)
 * Description: Self-host local fonts (TTF/OTF/WOFF/WOFF2) and apply a clean "Letter" style to headings and paragraphs.
 * Version: 1.0.1
 * Author: VKGS Consulting
 */
if ( ! defined('ABSPATH') ) exit;
define('VKGS_TYPO_LOCAL_URL', plugin_dir_url(__FILE__));
define('VKGS_TYPO_LOCAL_VER', '1.0.1');
add_action('enqueue_block_assets', function(){
  wp_enqueue_style('vkgs-typo-local', VKGS_TYPO_LOCAL_URL.'assets/typography-local.css', [], VKGS_TYPO_LOCAL_VER);
});
add_action('enqueue_block_editor_assets', function(){
  wp_enqueue_style('vkgs-typo-local-editor', VKGS_TYPO_LOCAL_URL.'assets/editor.css', ['vkgs-typo-local'], VKGS_TYPO_LOCAL_VER);
});
add_action('init', function(){
  if ( function_exists('register_block_style') ) {
    register_block_style('core/heading', [
      'name'  => 'vkgs-letter-heading',
      'label' => __('VKGS Letter — Heading', 'vkgs-typography-local'),
      'inline_style' => '.is-style-vkgs-letter-heading{font-family:var(--vkgs-font, Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif);font-weight:400;font-size:16px;line-height:1.6;letter-spacing:.005em;text-align:center;color:#0f172a;margin-bottom:12px;}'
    ]);
    register_block_style('core/paragraph', [
      'name'  => 'vkgs-letter-body',
      'label' => __('VKGS Letter — Body', 'vkgs-typography-local'),
      'inline_style' => '.is-style-vkgs-letter-body{font-family:var(--vkgs-font, Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif);font-weight:300;font-size:13.5px;line-height:1.85;color:#334155;margin:0 0 14px;} .is-style-vkgs-letter-body strong{font-weight:500;color:#0f172a;}'
    ]);
  }
});